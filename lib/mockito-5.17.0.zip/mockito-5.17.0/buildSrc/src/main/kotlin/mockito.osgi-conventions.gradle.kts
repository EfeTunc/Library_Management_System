plugins {
    id("biz.aQute.bnd.builder")
}
