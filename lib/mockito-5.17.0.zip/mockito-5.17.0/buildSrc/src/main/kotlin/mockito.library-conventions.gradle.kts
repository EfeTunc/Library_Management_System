plugins {
    base
    id("mockito.java-library-conventions")
    id("mockito.osgi-conventions")
    id("mockito.publication-conventions")
    id("mockito.quality-checkstyle-conventions")
    id("mockito.quality-spotless-conventions")
    id("mockito.license-conventions")
}
