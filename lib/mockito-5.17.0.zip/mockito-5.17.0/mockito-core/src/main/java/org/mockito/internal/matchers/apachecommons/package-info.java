/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Argument matchers that use Apache Commons Lang reflection-equality.
 */
package org.mockito.internal.matchers.apachecommons;
