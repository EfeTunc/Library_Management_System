/*
 * Copyright (c) 2007 Mockito contributors
 * This program is made available under the terms of the MIT License.
 */

/**
 * Mock makers based on the {@link java.lang.reflect.Proxy} utility.
 */
package org.mockito.internal.creation.proxy;
