create definer = root@`%` trigger does_user_reserved_exceeds_and_account
    before insert
    on reservations
    for each row
BEGIN
    IF (SELECT books_reserved FROM guests WHERE guestSSN = NEW.SSN) = 4 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Up to 4 books can be reserved.';
    ELSEIF (SELECT status FROM users WHERE SSN = NEW.SSN) <> 'active' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This account is not active.';
    END IF;
END;

