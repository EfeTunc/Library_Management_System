create definer = root@`%` trigger auto_user_adder
    after insert
    on users
    for each row
BEGIN
    IF NEW.role = 'admin' THEN
        INSERT INTO admins(adminSSN) VALUES (NEW.SSN);
    ELSEIF NEW.role = 'guest' THEN
        INSERT INTO guests(guestSSN) VALUES (NEW.SSN);
    END IF;
    END;

