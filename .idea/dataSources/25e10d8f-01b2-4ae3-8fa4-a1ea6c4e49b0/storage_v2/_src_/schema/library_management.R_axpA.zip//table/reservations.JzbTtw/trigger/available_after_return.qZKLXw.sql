create definer = root@`%` trigger available_after_return
    after update
    on reservations
    for each row
BEGIN
    UPDATE books
    SET availability = TRUE
    WHERE ISBN = NEW.ISBN;

    IF (SELECT role FROM users WHERE SSN = NEW.SSN) = 'guest' THEN
        UPDATE guests
        SET reserved_books = reserved_books - 1
        WHERE guestSSN = NEW.SSN;
    END IF;
END;

