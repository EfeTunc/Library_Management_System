create definer = root@`%` trigger unavailable_after_reservation
    after insert
    on reservations
    for each row
BEGIN
    UPDATE books
    SET availability = FALSE
    WHERE ISBN = NEW.ISBN;

    IF (SELECT role FROM users WHERE SSN = NEW.SSN) = 'guest' THEN
        UPDATE guests
        SET books_reserved = books_reserved + 1
        WHERE guestSSN = NEW.SSN;
    END IF;
END;

