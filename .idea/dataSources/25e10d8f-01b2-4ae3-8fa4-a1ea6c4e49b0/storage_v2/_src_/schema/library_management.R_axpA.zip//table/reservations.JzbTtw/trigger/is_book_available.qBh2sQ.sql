create definer = root@`%` trigger is_book_available
    before insert
    on reservations
    for each row
BEGIN
    IF (SELECT availability FROM books WHERE ISBN = NEW.ISBN) = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Book is already reserved!';
    END IF;
END;

